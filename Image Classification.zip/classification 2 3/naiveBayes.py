# naiveBayes.py
# -------------
# Licensing Information: Please do not distribute or publish solutions to this
# project. You are free to use and extend these projects for educational
# purposes. The Pacman AI projects were developed at UC Berkeley, primarily by
# John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# For more info, see http://inst.eecs.berkeley.edu/~cs188/sp09/pacman.html

import util
import classificationMethod
import math

class NaiveBayesClassifier(classificationMethod.ClassificationMethod):
  """
  See the project description for the specifications of the Naive Bayes classifier.
  
  Note that the variable 'datum' in this code refers to a counter of features
  (not to a raw samples.Datum).
  """
  def __init__(self, legalLabels):
    self.legalLabels = legalLabels
    self.type = "naivebayes"
    self.k = 1 # this is the smoothing parameter, ** use it in your train method **
    self.automaticTuning = False # Look at this flag to decide whether to choose k automatically ** use this in your train method **
    
  def setSmoothing(self, k):
    """
    This is used by the main method to change the smoothing parameter before training.
    Do not modify this method.
    """
    self.k = k

  def train(self, trainingData, trainingLabels, validationData, validationLabels):
    """
    Outside shell to call your method. Do not modify this method.
    """  
      
    # might be useful in your code later...
    # this is a list of all features in the training set.
    self.features = list(set([ f for datum in trainingData for f in datum.keys() ]));
    
    if (self.automaticTuning):
        kgrid = [0.001, 0.01, 0.05, 0.1, 0.5, 1, 5, 10, 20, 50]
    else:
        kgrid = [self.k]
        
    self.trainAndTune(trainingData, trainingLabels, validationData, validationLabels, kgrid)
      
  def trainAndTune(self, trainingData, trainingLabels, validationData, validationLabels, kgrid):
    """
    Trains the classifier by collecting counts over the training data, and
    stores the Laplace smoothed estimates so that they can be used to classify.
    Evaluate each value of k in kgrid to choose the smoothing parameter 
    that gives the best accuracy on the held-out validationData.
    
    trainingData and validationData are lists of feature Counters.  The corresponding
    label lists contain the correct label for each datum.
    
    To get the list of all possible features or labels, use self.features and 
    self.legalLabels.
    """

    "*** YOUR CODE HERE ***"
    
    prior = util.Counter()

    for y in trainingLabels:
      prior[y]+=1

    prior.normalize()

    cond_prob = util.Counter()
    count = util.Counter()

    for i in range(len(trainingData)):
      img = trainingData[i]
      lbl = trainingLabels[i]

      for x,y in img.items():
        count[(x,lbl)]+=1
        if y==1:
          cond_prob[(x,lbl)] += 1
    
    max_acc = 0

    for k in kgrid:
      k_p = util.Counter()
      k_cp = util.Counter()
      k_c = util.Counter()

      for key,value in prior.items():
        k_p[key] = value
      for key,value in cond_prob.items():
        k_cp[key] = value
      for key,value in count.items():
        k_c[key] = value

      for label in self.legalLabels:
        for pixels in self.features:
          k_cp[(pixels,label)]+=k
          k_c[(pixels,label)]+=k
      
      

      for key,value in k_cp.items():
        k_cp[key] = float(value)/k_c[key]
      
      self.prior = k_p
      self.conditional_probability = k_cp

      pred = self.classify(validationData)
      acc_count = 0

      for i in range(len(validationLabels)):
        if pred[i] == validationLabels[i]:
          acc_count+=1
      
      percent = (float(acc_count) / len(validationLabels)) * 100
      print("Accuracy for value k: ", k, " = ", percent)

      if percent > max_acc:
        max_acc = percent
        self.k = (k_p, k_cp, k)
      
  def classify(self, testData):
    """
    Classify the data based on the posterior distribution over labels.
    
    You shouldn't modify this method.
    """
    guesses = []
    self.posteriors = [] # Log posteriors are stored for later data analysis (autograder).
    for datum in testData:
      posterior = self.calculateLogJointProbabilities(datum)
      guesses.append(posterior.argMax())
      self.posteriors.append(posterior)
    return guesses
      
  def calculateLogJointProbabilities(self, datum):
    """
    Returns the log-joint distribution over legal labels and the datum.
    Each log-probability should be stored in the log-joint counter, e.g.    
    logJoint[3] = <Estimate of log( P(Label = 3, datum) )>
    
    To get the list of all possible features or labels, use self.features and 
    self.legalLabels.
    """
    logJoint = util.Counter()
    
    "*** YOUR CODE HERE ***"
    
    for label in self.legalLabels:
            logJoint[label] = math.log(self.prior[label])
            for location, value in datum.items():
                # print self.conditionalProb[(location, value)]
                if value == 0:
                    x = 1 - self.conditional_probability[(location, label)]
                    logJoint[label] += math.log(x if x > 0 else 1)
                    # logJoint[label] += math.log(1 - self.conditionalProb[(location, label)])
                else:
                    logJoint[label] += math.log(self.conditional_probability[(location, label)])

    return logJoint

  
  def findHighOddsFeatures(self, label1, label2):
    """
    Returns the 100 best features for the odds ratio:
            P(feature=1 | label1)/P(feature=1 | label2) 
    
    Note: you may find 'self.features' a useful way to loop through all possible features
    """
    featuresOdds = []
       
    "*** YOUR CODE HERE ***"
    for f in self.features:
      featuresOdds.append((self.conditional_probability[f,label1]/self.conditional_probability[f,label2],f))
    featuresOdds.sort()
    featuresOdds = [f for val, f in featuresOdds[-100:]]
    return featuresOdds
    

    
      
