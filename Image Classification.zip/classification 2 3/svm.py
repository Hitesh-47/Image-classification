import util
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
PRINT = True

class SVMClassifier:
  def __init__( self, legalLabels, max_iterations):
    self.legalLabels = legalLabels
    self.type = "perceptron"
    self.max_iterations = max_iterations
    self.weights = {}
    self.logisticRegr = LogisticRegression()
    self.SVM = SVC(gamma='scale')
    for label in legalLabels:
      self.weights[label] = util.Counter() # this is the data-structure you should use

  def setWeights(self, weights):
    assert len(weights) == len(self.legalLabels);
    self.weights == weights
      
  def train( self, trainingData, trainingLabels, validationData, validationLabels ):
    """
    The training loop for the perceptron passes through the training data several
    times and updates the weight vector for each label based on classification errors.
    See the project description for details. 
    
    Use the provided self.weights[label] data structure so that 
    the classify method works correctly. Also, recall that a
    datum is a counter from features to values for those features
    (and thus represents a vector a values).
    """
    
    self.features = list(trainingData[0].keys()) # could be useful later
    # DO NOT ZERO OUT YOUR WEIGHTS BEFORE STARTING TRAINING, OR
    # THE AUTOGRADER WILL LIKELY DEDUCT POINTS.
   
    X_train = []
    Y_train = []
    X_validation = []
    for data in trainingData:
      X_train.append(list(data.values()))
  
    for lbl in trainingLabels:
      Y_train.append(lbl)
    
    #self.logisticRegr.fit(X_train, Y_train)
    self.SVM.fit(X_train,Y_train)

    for data in validationData:
      X_validation.append(list(data.values()))

    
          
    
  def classify(self, data ):
    """
    Classifies each datum as the label that most closely matches the prototype vector
    for that label.  See the project description for details.
    
    Recall that a datum is a util.counter... 
    """
    preds = []
    X_values = []
    for d in data:
      X_values.append(list(d.values()))
    
    #preds = self.logisticRegr.predict(X_values)
    preds = self.SVM.predict(X_values)
    
    return preds

  
  def findHighWeightFeatures(self, label):
    """
    Returns a list of the 100 features with the greatest weight for some label
    """
    featuresWeights = []

    "*** YOUR CODE HERE ***"
    featuresWeights = self.weights[label].sortedKeys()[:100]
    

    return featuresWeights